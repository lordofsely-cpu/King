package com.sely.assistant

import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Log
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL

/**
 * Executes every Sely command (memory, reminders, calling/texting, app launching, media,
 * device toggles, and Gemini Q&A). This is the single source of truth for command behavior:
 * MainActivity uses it for typed/tapped/foreground voice commands, and SelyWakeService uses
 * it to run commands heard after "Hey Sely" directly, without needing to open MainActivity.
 *
 * [context] can be an Activity (enables dialogs like the inbox list) or a Service context
 * (any activity that gets launched is started with FLAG_ACTIVITY_NEW_TASK instead).
 */
class SelyCommandProcessor(
    private val context: Context,
    private val callbacks: Callbacks
) {

    interface Callbacks {
        /** Speak [text] aloud (and show it, if there's a UI). [onDone] fires once speech finishes. */
        fun speak(text: String, onDone: (() -> Unit)? = null)
        /** Optional short status update, e.g. for an on-screen status line. */
        fun updateStatus(text: String) {}
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences("sely_prefs", Context.MODE_PRIVATE)

    // Q&A pairs for this processor's lifetime only, used so Gemini follow-up questions have context.
    private val conversationHistory = mutableListOf<Pair<String, String>>()

    private fun speak(text: String, onDone: (() -> Unit)? = null) {
        callbacks.updateStatus(text)
        callbacks.speak(text, onDone)
    }

    /**
     * Runs [command]. Every branch below is expected to call speak() exactly once so callers
     * that need to know when the response finished (like the wake service) can chain off it.
     * Any unexpected exception is caught here so the caller can never get stuck waiting.
     */
    fun process(command: String) {
        try {
            processInner(command)
        } catch (e: Exception) {
            Log.e(TAG, "Command failed: \"$command\"", e)
            speak("Sorry, something went wrong with that command.")
        }
    }

    private fun processInner(command: String) {
        when {
            command.startsWith("remember that ") -> rememberFact(command.removePrefix("remember that ").trim())
            command.startsWith("remember ") -> rememberFact(command.removePrefix("remember ").trim())
            command.contains("what do you remember") || command.contains("what have i told you") -> recallFacts()
            command.contains("forget everything") -> forgetAll()
            command.startsWith("remind me to ") -> handleReminderCommand(command)
            command.contains("what are my reminders") || command.contains("what's on my schedule") -> listReminders()
            command.startsWith("delete the reminder") || command.startsWith("delete reminder") || command.startsWith("cancel the reminder") -> deleteReminder(command)
            command.startsWith("reply saying ") -> prepareReply(command.removePrefix("reply saying ").trim())
            command == "confirm" || command == "yes send it" || command == "send it" -> confirmReply()
            command.contains("what's my last message") || command.contains("read my last message") || command.contains("do i have any messages") -> readLastMessage()
            command.contains("enable notification access") -> openNotificationAccessSettings()
            command.contains("what time is it") || command.contains("what's the time") -> tellTime()
            command.contains("battery") -> tellBattery()
            command.contains("volume up") || command.contains("turn up the volume") -> adjustVolume(true)
            command.contains("volume down") || command.contains("turn down the volume") -> adjustVolume(false)
            command.contains("turn on wifi") || command.contains("turn off wifi") -> openWifiSettings()
            command.contains("turn on bluetooth") || command.contains("turn off bluetooth") -> openBluetoothSettings()
            command.contains("read my messages") || command.contains("check my inbox") || command.contains("my inbox") -> showInbox()
            command.contains("lock my phone") || command.contains("lock the phone") -> lockPhone()
            command.contains("block notifications") || command.contains("block my notifications") || command.contains("turn on do not disturb") -> blockNotifications()
            command.contains("unblock notifications") || command.contains("turn off do not disturb") || command.contains("allow notifications") -> unblockNotifications()
            command.startsWith("play ") -> playMusic(command.removePrefix("play ").trim())
            command == "pause music" || command == "pause" -> sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PAUSE)
            command == "resume music" || command == "resume" || command == "unpause" -> sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
            command.contains("next song") || command.contains("skip") -> sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
            command.contains("previous song") || command.contains("last song") -> sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            command == "stop music" || command == "stop" -> sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_STOP)
            command.contains("answer the call") || command == "answer" || command == "pick up" || command.contains("pick up the call") -> answerCall()
            command.contains("turn on busy mode") -> setBusyMode(true)
            command.contains("turn off busy mode") -> setBusyMode(false)
            command.startsWith("set busy message to ") -> setBusyMessage(command.removePrefix("set busy message to ").trim())
            command.startsWith("set busy call message to ") -> setBusyCallMessage(command.removePrefix("set busy call message to ").trim())
            command.contains("whatsapp") -> handleWhatsAppCommand(command)
            command.contains("open camera") -> {
                speak("Opening the camera now.")
                openCamera()
            }
            command.contains("open gmail") || command.contains("open email") -> {
                speak("Opening your email.")
                openApp("com.google.android.gm")
            }
            command.contains("turn on flashlight") || command.contains("flashlight on") -> {
                setFlashlight(true)
                speak("Flashlight's on.")
            }
            command.contains("turn off flashlight") || command.contains("flashlight off") -> {
                setFlashlight(false)
                speak("Flashlight's off.")
            }
            command.startsWith("open ") -> openAppByName(command.removePrefix("open ").trim())
            command.startsWith("call ") -> {
                val target = command.substringAfter("call ").trim()
                val number = resolveTarget(target)
                if (number == null) {
                    speak("I couldn't find a contact called $target.")
                } else {
                    speak("Calling $target now.")
                    callContact(number)
                }
            }
            command.startsWith("text ") -> handleTextCommand(command)
            else -> askGemini(command)
        }
    }

    // ---- Intent launching: adds NEW_TASK when we're not running inside an Activity ----
    private fun launchIntent(intent: Intent) {
        if (context !is Activity) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    // ---- Memory ----
    private fun loadMemories(): MutableList<String> {
        val raw = prefs.getString("sely_memories", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) list.add(arr.getString(i))
        return list
    }

    private fun saveMemories(list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        prefs.edit().putString("sely_memories", arr.toString()).apply()
    }

    private fun rememberFact(fact: String) {
        if (fact.isEmpty()) {
            speak("What should I remember?")
            return
        }
        val memories = loadMemories()
        memories.add(fact)
        saveMemories(memories)
        speak("Got it, I'll remember that $fact.")
    }

    private fun recallFacts() {
        val memories = loadMemories()
        if (memories.isEmpty()) {
            speak("You haven't told me anything to remember yet.")
        } else {
            speak("Here's what I remember. ${memories.joinToString(". ")}")
        }
    }

    private fun forgetAll() {
        saveMemories(emptyList())
        speak("Okay, I've forgotten everything you told me.")
    }

    // ---- Reminders ----
    private fun handleReminderCommand(command: String) {
        val rest = command.removePrefix("remind me to ").trim()
        val atIndex = rest.lastIndexOf(" at ")
        if (atIndex == -1) {
            speak("Say it like: remind me to call mom at 5 PM.")
            return
        }
        val task = rest.substring(0, atIndex).trim()
        val timePart = rest.substring(atIndex + 4).trim()
        val cal = parseTimeToCalendar(timePart)
        if (cal == null) {
            speak("I couldn't understand that time. Try something like 5 PM or 5:30.")
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            speak("I need permission to schedule exact alarms first. Opening settings — please turn it on, then try again.")
            launchIntent(Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
            return
        }

        val requestCode = (task + timePart).hashCode()
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("reminder_text", task)
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pendingIntent)

        val display = android.text.format.DateFormat.format("h:mm a, EEE", cal).toString()
        val reminders = loadReminderObjects()
        reminders.put(JSONObject().apply {
            put("task", task)
            put("display", display)
            put("requestCode", requestCode)
        })
        saveReminderObjects(reminders)

        speak("Okay, I'll remind you to $task at $display.")
    }

    private fun parseTimeToCalendar(timePart: String): java.util.Calendar? {
        val regex = Regex("""(\d{1,2})(?::(\d{2}))?\s*(am|pm)?""", RegexOption.IGNORE_CASE)
        val match = regex.find(timePart) ?: return null
        var hour = match.groupValues[1].toIntOrNull() ?: return null
        val minute = match.groupValues[2].toIntOrNull() ?: 0
        val meridiem = match.groupValues[3].lowercase()

        if (meridiem == "pm" && hour < 12) hour += 12
        if (meridiem == "am" && hour == 12) hour = 0

        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, hour)
        cal.set(java.util.Calendar.MINUTE, minute)
        cal.set(java.util.Calendar.SECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) {
            cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
        return cal
    }

    private fun loadReminderObjects(): JSONArray {
        val raw = prefs.getString("sely_reminder_list", "[]") ?: "[]"
        return JSONArray(raw)
    }

    private fun saveReminderObjects(arr: JSONArray) {
        prefs.edit().putString("sely_reminder_list", arr.toString()).apply()
    }

    private fun listReminders() {
        val reminders = loadReminderObjects()
        if (reminders.length() == 0) {
            speak("You have no reminders set.")
        } else {
            val parts = mutableListOf<String>()
            for (i in 0 until reminders.length()) {
                val obj = reminders.getJSONObject(i)
                parts.add("${obj.getString("task")} at ${obj.getString("display")}")
            }
            speak("Here's what's coming up. ${parts.joinToString(". ")}")
        }
    }

    private fun deleteReminder(command: String) {
        val reminders = loadReminderObjects()
        if (reminders.length() == 0) {
            speak("You don't have any reminders set.")
            return
        }
        var matchIndex = -1
        var matchTask = ""
        var matchRequestCode = 0
        for (i in 0 until reminders.length()) {
            val obj = reminders.getJSONObject(i)
            val task = obj.getString("task").lowercase()
            if (command.contains(task)) {
                matchIndex = i
                matchTask = obj.getString("task")
                matchRequestCode = obj.getInt("requestCode")
                break
            }
        }
        if (matchIndex == -1) {
            speak("I couldn't find a reminder matching that. Say \"what are my reminders\" to hear them.")
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val cancelIntent = Intent(context, ReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, matchRequestCode, cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)

        val updated = JSONArray()
        for (i in 0 until reminders.length()) {
            if (i != matchIndex) updated.put(reminders.getJSONObject(i))
        }
        saveReminderObjects(updated)

        speak("Deleted the reminder to $matchTask, and cancelled the alarm.")
    }

    // ---- Time / battery / volume ----
    private fun tellTime() {
        val now = android.text.format.DateFormat.format("h:mm a", java.util.Calendar.getInstance()).toString()
        speak("It's $now.")
    }

    private fun tellBattery() {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
        val level = batteryManager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        speak("Your battery is at $level percent.")
    }

    private fun adjustVolume(up: Boolean) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        audioManager.adjustStreamVolume(
            android.media.AudioManager.STREAM_MUSIC,
            if (up) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER,
            android.media.AudioManager.FLAG_SHOW_UI
        )
        speak(if (up) "Turning it up." else "Turning it down.")
    }

    // Android blocks apps from silently toggling WiFi/Bluetooth since Android 10 — the safe,
    // policy-compliant way is to open the relevant settings panel for the user to flip it themselves.
    private fun openWifiSettings() {
        speak("Opening WiFi settings for you.")
        launchIntent(Intent(android.provider.Settings.Panel.ACTION_WIFI))
    }

    private fun openBluetoothSettings() {
        speak("Opening Bluetooth settings for you.")
        launchIntent(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
    }

    // ---- Lock screen: requires Device Admin ----
    private fun lockPhone() {
        val devicePolicyManager = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
        val adminComponent = android.content.ComponentName(context, SelyDeviceAdminReceiver::class.java)

        if (!devicePolicyManager.isAdminActive(adminComponent)) {
            speak("I need permission to lock the screen first. Opening settings — please turn it on, then try again.")
            val intent = Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                putExtra(
                    android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Sely needs this to lock your phone when you ask it to."
                )
            }
            launchIntent(intent)
            return
        }

        try {
            devicePolicyManager.lockNow()
            speak("Locked.")
        } catch (e: Exception) {
            speak("Sorry, I couldn't lock the phone.")
        }
    }

    // ---- Do Not Disturb ----
    private fun blockNotifications() {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!notificationManager.isNotificationPolicyAccessGranted) {
            speak("I need notification access first. Opening settings — please turn it on for Sely, then try again.")
            launchIntent(Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return
        }
        notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        speak("Notifications blocked. Good luck.")
    }

    private fun unblockNotifications() {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!notificationManager.isNotificationPolicyAccessGranted) {
            speak("Notification access isn't turned on, so there's nothing to undo.")
            return
        }
        notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
        speak("Notifications are back on.")
    }

    // ---- Inbox: shows a dialog when we have an Activity, otherwise just speaks the messages ----
    private fun showInbox() {
        val raw = prefs.getString("recent_messages", "[]") ?: "[]"
        val arr = JSONArray(raw)
        if (arr.length() == 0) {
            speak("Your inbox is empty, or notification access isn't turned on yet.")
            return
        }
        val dialogLines = StringBuilder()
        val spokenLines = StringBuilder()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val sender = obj.getString("sender")
            val text = obj.getString("text")
            dialogLines.append("$sender: $text\n")
            if (i < 5) spokenLines.append("$sender says $text. ")
        }
        val activity = context as? Activity
        if (activity != null && !activity.isFinishing) {
            AlertDialog.Builder(activity)
                .setTitle("Recent messages")
                .setMessage(dialogLines.toString().trim())
                .setPositiveButton("Close", null)
                .show()
            speak("Here's your inbox.")
        } else {
            speak(spokenLines.toString().trim())
        }
    }

    // ---- Incoming messages: read via NotificationListener, reply requires spoken confirmation ----
    private fun readLastMessage() {
        val sender = prefs.getString("last_message_sender", null)
        val text = prefs.getString("last_message_text", null)
        if (sender == null || text == null) {
            speak("You have no recent messages, or notification access isn't turned on yet. Say enable notification access to fix that.")
        } else {
            speak("$sender says: $text")
        }
    }

    private var pendingReplyText: String? = null

    private fun prepareReply(messageText: String) {
        if (SelyNotificationListener.lastReplyAction == null) {
            speak("I don't have a live message to reply to right now. Open the chat once, then try again.")
            return
        }
        pendingReplyText = messageText
        val sender = SelyNotificationListener.lastSender ?: "them"
        speak("Ready to send to $sender: $messageText. Say confirm to send it.")
    }

    private fun confirmReply() {
        val text = pendingReplyText
        val action = SelyNotificationListener.lastReplyAction
        if (text == null || action == null) {
            speak("There's nothing waiting to be sent.")
            return
        }
        try {
            val remoteInput = action.remoteInputs!!.first()
            val intent = Intent()
            val bundle = Bundle()
            bundle.putCharSequence(remoteInput.resultKey, text)
            android.app.RemoteInput.addResultsToIntent(action.remoteInputs, intent, bundle)
            action.actionIntent.send(context, 0, intent)
            speak("Sent.")
        } catch (e: Exception) {
            speak("Sorry, I couldn't send that reply.")
        }
        pendingReplyText = null
    }

    private fun openNotificationAccessSettings() {
        speak("Opening notification access settings. Please turn on access for Sely.")
        launchIntent(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
    }

    // ---- Music / media ----
    private fun sendMediaKey(keyCode: Int) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val eventTime = android.os.SystemClock.uptimeMillis()

        val downEvent = android.view.KeyEvent(eventTime, eventTime, android.view.KeyEvent.ACTION_DOWN, keyCode, 0)
        val upEvent = android.view.KeyEvent(eventTime, eventTime, android.view.KeyEvent.ACTION_UP, keyCode, 0)
        audioManager.dispatchMediaKeyEvent(downEvent)
        audioManager.dispatchMediaKeyEvent(upEvent)

        val label = when (keyCode) {
            android.view.KeyEvent.KEYCODE_MEDIA_PAUSE -> "Paused."
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY -> "Resuming."
            android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> "Skipping."
            android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> "Going back."
            android.view.KeyEvent.KEYCODE_MEDIA_STOP -> "Stopped."
            else -> "Done."
        }
        speak(label)
    }

    private fun playMusic(songQuery: String) {
        if (songQuery.isEmpty()) {
            speak("What should I play?")
            return
        }
        val intent = Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(android.app.SearchManager.QUERY, songQuery)
            putExtra("android.intent.extra.focus", "vnd.android.cursor.item/*")
        }
        try {
            launchIntent(intent)
            speak("Playing $songQuery.")
        } catch (e: Exception) {
            speak("I couldn't find a music app to play that with.")
        }
    }

    // ---- Calls ----
    private fun answerCall() {
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.ANSWER_PHONE_CALLS)
            != PackageManager.PERMISSION_GRANTED) {
            speak("I need call-answering permission first. Please grant it in the app permissions.")
            return
        }
        try {
            val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager
            telecomManager.acceptRingingCall()
            speak("Answered.")
        } catch (e: Exception) {
            speak("I couldn't answer the call.")
        }
    }

    private fun setBusyMode(on: Boolean) {
        prefs.edit().putBoolean("busy_mode", on).apply()
        speak(if (on) "Busy mode on. I'll let people know you're busy until you turn this off." else "Busy mode off.")
    }

    private fun setBusyMessage(message: String) {
        prefs.edit().putString("busy_reply_message", message).apply()
        speak("Got it, I'll send that when busy mode is on.")
    }

    private fun setBusyCallMessage(message: String) {
        prefs.edit().putString("busy_call_message", message).apply()
        speak("Got it, I'll say that to callers when busy mode is on.")
    }

    private fun lookupPhoneNumber(name: String): String? {
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) return null

        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return it.getString(numberIndex).replace(" ", "").replace("-", "")
            }
        }
        return null
    }

    private fun resolveTarget(spoken: String): String? {
        return if (spoken.any { it.isDigit() }) spoken else lookupPhoneNumber(spoken)
    }

    private fun callContact(number: String) {
        launchIntent(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
    }

    private fun handleTextCommand(command: String) {
        // Expected pattern: "text <name or number> <message>"
        val rest = command.substringAfter("text ").trim()
        val parts = rest.split(" ", limit = 2)
        if (parts.size < 2) {
            speak("Say it like: text, the name or number, then your message.")
            return
        }
        val number = resolveTarget(parts[0])
        val message = parts[1]
        if (number == null) {
            speak("I couldn't find a contact called ${parts[0]}.")
            return
        }
        try {
            val smsManager = android.telephony.SmsManager.getDefault()
            smsManager.sendTextMessage(number, null, message, null, null)
            speak("Sent it.")
        } catch (e: Exception) {
            speak("Sorry, I couldn't send that message.")
        }
    }

    private fun handleWhatsAppCommand(command: String) {
        // Expected pattern: "whatsapp <name or number> <message>" — e.g. "whatsapp mom I'm on my way"
        val rest = command.substringAfter("whatsapp").trim()
        val parts = rest.split(" ", limit = 2)

        if (parts.isEmpty() || parts[0].isEmpty() || parts.size < 2) {
            speak("Opening WhatsApp for you.")
            openApp("com.whatsapp")
            return
        }

        val number = resolveTarget(parts[0])
        if (number == null) {
            speak("I couldn't find a contact called ${parts[0]}.")
            return
        }
        val message = parts[1]
        try {
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=$number&text=${Uri.encode(message)}")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.whatsapp") }
            launchIntent(intent)
            speak("Opening WhatsApp with your message. Tap send when you're ready.")
        } catch (e: Exception) {
            speak("Sorry, I couldn't open that chat.")
        }
    }

    // ---- Apps / camera / flashlight ----
    private fun openAppByName(spokenName: String) {
        if (spokenName.isEmpty()) {
            speak("Which app should I open?")
            return
        }
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val installedApps = pm.queryIntentActivities(mainIntent, 0)

        val match = installedApps.firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(spokenName.lowercase())
        }

        if (match == null) {
            speak("I couldn't find an app called $spokenName.")
            return
        }

        val appIntent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
        if (appIntent != null) {
            launchIntent(appIntent)
            speak("Opening ${match.loadLabel(pm)}.")
        } else {
            speak("I found $spokenName but couldn't open it.")
        }
    }

    private fun openApp(packageName: String) {
        val appIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (appIntent != null) {
            launchIntent(appIntent)
        } else {
            speak("That app isn't installed.")
        }
    }

    private fun openCamera() {
        val intent = Intent("android.media.action.IMAGE_CAPTURE")
        if (intent.resolveActivity(context.packageManager) != null) {
            launchIntent(intent)
        }
    }

    private fun setFlashlight(on: Boolean) {
        try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList[0]
            cameraManager.setTorchMode(cameraId, on)
        } catch (e: Exception) {
            Log.e(TAG, "Flashlight control failed", e)
        }
    }

    // ---- Gemini ----
    private fun memoryContextBlock(): String {
        val memories = loadMemories()
        if (memories.isEmpty()) return ""
        return " Here are things the user has told you to remember, use them if relevant: " +
            memories.joinToString("; ") + "."
    }

    private fun conversationContextBlock(): String {
        if (conversationHistory.isEmpty()) return ""
        val recent = conversationHistory.joinToString(" ") { (q, a) -> "User asked: $q. You answered: $a." }
        return " Recent conversation this session, for context on follow-up questions: $recent"
    }

    private fun askGemini(question: String) {
        val key = prefs.getString("gemini_key", "") ?: ""
        if (key.isEmpty()) {
            speak("Please add your Gemini key in settings first.")
            return
        }
        callbacks.updateStatus("Thinking...")
        Thread {
            val answer = try {
                // Model uses Google's "latest" alias so it keeps working as Gemini versions roll forward.
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                // The key travels in a header, never in the URL, so it never ends up in logs.
                connection.setRequestProperty("x-goog-api-key", key)
                connection.doOutput = true
                connection.connectTimeout = 15000
                connection.readTimeout = 60000 // Gemini can take a while on longer answers

                val systemPrompt = "You are Sely, a personal voice assistant on the user's phone. " +
                    "If asked who created you, say you were created by a smart developer called Kingsley. " +
                    "Answer briefly and conversationally, in 1-3 sentences, since your answer will be spoken aloud." +
                    memoryContextBlock() + conversationContextBlock()

                val body = JSONObject().apply {
                    put("systemInstruction", JSONObject().apply {
                        put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
                    })
                    put("contents", JSONArray().put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().put(JSONObject().put("text", question)))
                    }))
                }

                connection.outputStream.use { it.write(body.toString().toByteArray()) }

                val responseCode = connection.responseCode
                val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
                val responseText = stream?.bufferedReader()?.use { it.readText() } ?: ""
                val json = if (responseText.isNotBlank()) JSONObject(responseText) else JSONObject()

                if (responseCode in 200..299 && json.has("candidates")) {
                    json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                        .trim()
                } else {
                    // Surface Gemini's actual error message instead of a generic "can't reach it"
                    val apiMessage = json.optJSONObject("error")?.optString("message")
                    if (!apiMessage.isNullOrBlank()) {
                        "Gemini error: $apiMessage"
                    } else {
                        "Gemini returned an error (HTTP $responseCode) and didn't explain why."
                    }
                }
            } catch (e: SocketTimeoutException) {
                "Gemini took too long to respond. Please try again."
            } catch (e: IOException) {
                "I couldn't reach Gemini: ${e.message ?: e.javaClass.simpleName}."
            } catch (e: Exception) {
                "Gemini error: ${e.javaClass.simpleName}: ${e.message}"
            }

            conversationHistory.add(question to answer)
            if (conversationHistory.size > 6) conversationHistory.removeAt(0)
            speak(answer)
        }.start()
    }

    companion object {
        private const val TAG = "SelyCommandProcessor"
    }
}
