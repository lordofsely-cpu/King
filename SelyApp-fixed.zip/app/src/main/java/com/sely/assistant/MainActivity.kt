package com.sely.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity(), SelyCommandProcessor.Callbacks {

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var statusText: TextView
    private lateinit var textToSpeech: TextToSpeech
    private lateinit var prefs: SharedPreferences
    private lateinit var orbButton: ImageButton
    private lateinit var chatLog: LinearLayout
    private lateinit var scrollContainer: ScrollView
    private var pulseAnimator: ObjectAnimator? = null
    private var ttsReady = false

    // Single shared command processor — this is what actually runs every command, whether it
    // came from tapping the orb, typing, or (via SelyWakeService) saying "Hey Sely" elsewhere.
    private val commandProcessor by lazy { SelyCommandProcessor(this, this) }

    private val requiredPermissions: Array<String>
        get() {
            val base = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CAMERA
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                base.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            base.add(Manifest.permission.READ_PHONE_STATE)
            base.add(Manifest.permission.READ_CALL_LOG)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                base.add(Manifest.permission.ANSWER_PHONE_CALLS)
            }
            return base.toTypedArray()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        orbButton = findViewById(R.id.orbButton)
        chatLog = findViewById(R.id.chatLog)
        scrollContainer = findViewById(R.id.scrollContainer)
        val settingsButton = findViewById<TextView>(R.id.settingsButton)
        val chatInput = findViewById<EditText>(R.id.chatInput)
        val chatSendButton = findViewById<Button>(R.id.chatSendButton)

        val sendTypedCommand = {
            try {
                val typed = chatInput.text.toString().trim()
                if (typed.isNotEmpty()) {
                    addChatBubble(typed, isUser = true)
                    chatInput.setText("")
                    handleCommand(typed.lowercase())
                }
            } catch (e: Exception) {
                statusText.text = "Send error: ${e.javaClass.simpleName}: ${e.message}"
            }
        }
        chatSendButton.setOnClickListener { sendTypedCommand() }
        chatInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE ||
                (event?.keyCode == android.view.KeyEvent.KEYCODE_ENTER && event.action == android.view.KeyEvent.ACTION_DOWN)) {
                sendTypedCommand()
                true
            } else false
        }

        prefs = getSharedPreferences("sely_prefs", Context.MODE_PRIVATE)

        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val savedLang = prefs.getString("sely_language", "en-US") ?: "en-US"
                textToSpeech.language = java.util.Locale.forLanguageTag(savedLang)
                ttsReady = true
                if (pendingGreeting) {
                    pendingGreeting = false
                    runOnUiThread { greetThenListen() }
                }
            }
        }

        settingsButton.setOnClickListener { showApiKeyDialog() }
        val helpButton = findViewById<TextView>(R.id.helpButton)
        helpButton.setOnClickListener { showHelpDialog() }

        requestNeededPermissions()

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                statusText.text = "Listening..."
                startPulse()
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val command = matches?.firstOrNull()?.lowercase() ?: ""
                statusText.text = if (command.isNotEmpty()) "Heard: \"$command\"" else "Didn't catch that"
                if (command.isEmpty()) stopPulse()
                if (command.isNotEmpty()) {
                    addChatBubble(command, isUser = true)
                    handleCommand(command)
                }
            }

            override fun onError(error: Int) {
                statusText.text = "Didn't catch that — tap to try again"
                stopPulse()
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
        })

        orbButton.setOnClickListener { startListening() }

        handleWakeIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWakeIntent(intent)
    }

    // SelyWakeService now executes commands directly and only opens MainActivity when there's
    // nothing to run headlessly (auto_listen) or a typed/tapped follow-up makes sense.
    private fun handleWakeIntent(intent: Intent) {
        val pendingCommand = intent.getStringExtra("pending_command")
        if (!pendingCommand.isNullOrEmpty()) {
            addChatBubble(pendingCommand, isUser = true)
            handleCommand(pendingCommand)
            return
        }
        if (intent.getBooleanExtra("auto_listen", false)) {
            if (ttsReady) greetThenListen() else pendingGreeting = true
        }
    }

    private var pendingGreeting = false

    private val wakeGreetings = listOf(
        "Hello boss, what do you need?",
        "Yes boss, I'm listening.",
        "Hello boss, go ahead."
    )

    private fun greetThenListen() {
        speak(wakeGreetings.random())
        orbButton.postDelayed({ startListening() }, 1800)
    }

    private fun startPulse() {
        pulseAnimator?.cancel()
        pulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
            orbButton,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.1f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.1f)
        ).apply {
            duration = 550
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    private fun stopPulse() {
        pulseAnimator?.cancel()
        orbButton.scaleX = 1f
        orbButton.scaleY = 1f
    }

    private fun requestNeededPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    private fun startListening() {
        val languageCode = prefs.getString("sely_language", "en-US") ?: "en-US"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode)
        }
        try {
            speechRecognizer.startListening(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Microphone not available", Toast.LENGTH_SHORT).show()
        }
    }

    // Every command — typed, tapped, or heard — runs through the shared processor so behavior
    // is identical no matter how it got here.
    private fun handleCommand(command: String) {
        commandProcessor.process(command)
    }

    // ---- SelyCommandProcessor.Callbacks ----
    override fun speak(text: String, onDone: (() -> Unit)?) {
        runOnUiThread {
            addChatBubble(text, isUser = false)
            if (ttsReady) {
                textToSpeech.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        runOnUiThread { stopPulse(); onDone?.invoke() }
                    }
                    override fun onError(utteranceId: String?) {
                        runOnUiThread { stopPulse(); onDone?.invoke() }
                    }
                })
                textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sely_utterance")
            } else {
                stopPulse()
                onDone?.invoke()
            }
        }
    }

    override fun updateStatus(text: String) {
        runOnUiThread { statusText.text = text }
    }

    // Kotlin doesn't let an interface override redeclare its default parameter value, so this
    // plain overload covers the many call sites here that don't care about the onDone callback.
    private fun speak(text: String) = speak(text, null)

    private fun addChatBubble(text: String, isUser: Boolean) {
        val bubble = TextView(this)
        bubble.text = text
        bubble.textSize = 14f
        val hPad = (16 * resources.displayMetrics.density).toInt()
        val vPad = (10 * resources.displayMetrics.density).toInt()
        bubble.setPadding(hPad, vPad, hPad, vPad)
        bubble.setTextColor(resources.getColor(if (isUser) android.R.color.white else R.color.text, theme))
        bubble.maxWidth = (resources.displayMetrics.widthPixels * 0.78).toInt()
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.gravity = if (isUser) android.view.Gravity.END else android.view.Gravity.START
        params.topMargin = (6 * resources.displayMetrics.density).toInt()
        params.bottomMargin = (6 * resources.displayMetrics.density).toInt()
        bubble.layoutParams = params
        bubble.setBackgroundResource(if (isUser) R.drawable.bubble_user else R.drawable.bubble_sely)
        chatLog.addView(bubble)
        scrollContainer.post { scrollContainer.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    private fun showHelpDialog() {
        val commandsText = "\u2022 \"open [any app]\" \u2014 e.g. \"open spotify\"\n" +
            "\u2022 \"open whatsapp\" / \"whatsapp mom I'm on my way\"\n" +
            "\u2022 \"call mom\" / \"text mom ...\"\n" +
            "\u2022 \"play [song]\", \"pause\", \"resume\", \"skip\", \"stop\"\n" +
            "\u2022 \"answer\" (during an announced call)\n" +
            "\u2022 \"turn on/off busy mode\", \"set busy message to ...\"\n" +
            "\u2022 \"set busy call message to ...\"\n" +
            "\u2022 \"turn on/off flashlight\", \"open camera\"\n" +
            "\u2022 \"lock my phone\"\n" +
            "\u2022 \"block notifications\" / \"unblock notifications\"\n" +
            "\u2022 \"remember that ...\", \"what do you remember\"\n" +
            "\u2022 \"remind me to ... at ...\", \"what are my reminders\"\n" +
            "\u2022 \"delete the reminder ...\"\n" +
            "\u2022 \"what time is it\", \"what's my battery\"\n" +
            "\u2022 \"volume up/down\", \"turn on wifi/bluetooth\"\n" +
            "\u2022 \"what's my last message\", \"check my inbox\"\n" +
            "\u2022 \"reply saying ...\" then \"confirm\"\n" +
            "\u2022 \"Hey Sely\" (if always-listen is on) \u2014 works even while another app is open\n" +
            "\u2022 or just ask a question \u2014 Sely remembers the conversation too"
        AlertDialog.Builder(this)
            .setTitle("Things you can say or type")
            .setMessage(commandsText)
            .setPositiveButton("Close", null)
            .show()
    }

    private fun showApiKeyDialog() {
        val input = EditText(this)
        input.hint = "Paste your free Gemini API key"
        input.setText(prefs.getString("gemini_key", ""))
        AlertDialog.Builder(this)
            .setTitle("Gemini API key")
            .setMessage("Get a free key at aistudio.google.com/apikey — no credit card needed.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("gemini_key", input.text.toString().trim()).apply()
                statusText.text = "Key saved"
            }
            .setNeutralButton(if (isWakeServiceRunning) "Turn off always-listen" else "Turn on always-listen (\"Hey Sely\")") { _, _ ->
                toggleWakeService()
            }
            .setNegativeButton("Language") { _, _ -> showLanguageDialog() }
            .show()

        if (!android.provider.Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("One more permission")
                .setMessage("For the floating Sely icon to appear when you say \"Hey Sely\" in other apps, allow \"display over other apps\" on the next screen.")
                .setPositiveButton("Open settings") { _, _ ->
                    val intent = Intent(
                        android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                }
                .setNegativeButton("Skip", null)
                .show()
        }
    }

    private val supportedLanguages = linkedMapOf(
        "English (US)" to "en-US",
        "English (UK)" to "en-GB",
        "Spanish" to "es-ES",
        "French" to "fr-FR",
        "Portuguese" to "pt-PT",
        "Hausa" to "ha-NG",
        "Yoruba" to "yo-NG",
        "Igbo" to "ig-NG",
        "Arabic" to "ar-SA",
        "Hindi" to "hi-IN"
    )

    private fun showLanguageDialog() {
        val names = supportedLanguages.keys.toTypedArray()
        val codes = supportedLanguages.values.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choose a language")
            .setItems(names) { _, index ->
                val code = codes[index]
                prefs.edit().putString("sely_language", code).apply()
                textToSpeech.language = java.util.Locale.forLanguageTag(code)
                statusText.text = "Language set to ${names[index]}"
                speak("Language set.")
            }
            .show()
    }

    private var isWakeServiceRunning = false

    private fun toggleWakeService() {
        val serviceIntent = Intent(this, SelyWakeService::class.java)
        if (isWakeServiceRunning) {
            stopService(serviceIntent)
            isWakeServiceRunning = false
            prefs.edit().putBoolean("always_listen_enabled", false).apply()
            statusText.text = "Always-listen turned off"
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            isWakeServiceRunning = true
            prefs.edit().putBoolean("always_listen_enabled", true).apply()
            statusText.text = "Always-listen on — say \"Hey Sely\" anytime, even in other apps"
        }
    }

    override fun onDestroy() {
        speechRecognizer.destroy()
        textToSpeech.stop()
        textToSpeech.shutdown()
        super.onDestroy()
    }
}
