package com.sely.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Runs "Hey Sely" wake-word detection in the background so it works while another app (Chrome,
 * WhatsApp, a game, etc.) is in the foreground, then executes the spoken command directly.
 *
 * Lifecycle rules enforced by the [state] machine below:
 *  - Exactly one SpeechRecognizer instance exists for the life of this service.
 *  - startListening() is never called again until the previous session has finished, i.e. its
 *    onResults()/onError() callback has already fired (SpeechRecognizer's documented contract).
 *  - Wake-word listening never restarts while a command is being processed or spoken.
 *  - Recognition and TTS never run at the same time.
 *
 * Flow: "Hey Sely" -> stop wake recognizer -> show floating icon -> ONE command recognition
 * session -> execute the command directly (no need to open MainActivity) -> speak the result ->
 * only once that speech finishes, resume wake-word listening.
 */
class SelyWakeService : Service(), SelyCommandProcessor.Callbacks {

    private enum class WakeState {
        IDLE, LISTENING_FOR_WAKE, LISTENING_FOR_COMMAND, PROCESSING_COMMAND, SPEAKING, HANDLING_CALL
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false
    private var enabled = false // user's "always-listen" toggle
    private var state = WakeState.IDLE
    private var floatingView: android.view.View? = null
    private var overlayWarningGiven = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private val commandProcessor by lazy { SelyCommandProcessor(this, this) }

    // Call-handling state, preserved across the brief detour into HANDLING_CALL
    private var wasEnabledBeforeCall = false
    private var awaitingCallResponse = false
    private var pendingSelfStop = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Say \"Hey Sely\" anytime"))
        ensureTts()

        if (intent?.action == "ANNOUNCE_CALL") {
            val callerLabel = intent.getStringExtra("caller_label") ?: "someone"
            handleIncomingCall(callerLabel)
            return START_STICKY
        }

        if (!enabled) {
            enabled = true
            ensureRecognizer()
            transitionToWakeListening()
        }
        return START_STICKY
    }

    private fun ensureTts() {
        if (textToSpeech != null) return
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale.US
                ttsReady = true
            }
        }
    }

    private fun ensureRecognizer() {
        if (speechRecognizer != null) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.e(TAG, "No speech recognition service available on this device")
            updateNotification("Speech recognition isn't available on this device")
            return
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(recognitionListener)
    }

    // ---- Single listener, single recognizer instance for the service's whole lifetime.
    // Behavior branches purely on `state`, which is only ever advanced from these callbacks or
    // from a speak()-completion callback — never from an independent timer racing against them.
    private val recognitionListener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val heard = firstResult(results)
            when (state) {
                WakeState.LISTENING_FOR_WAKE -> {
                    updateNotification(if (heard.isEmpty()) "Say \"Hey Sely\" anytime" else "Last heard: \"$heard\"")
                    if (containsWakeWord(heard)) {
                        beginCommandFlow()
                    } else {
                        transitionToWakeListening()
                    }
                }
                WakeState.LISTENING_FOR_COMMAND -> onCommandHeard(heard)
                else -> { /* stray callback from a session we already moved past; ignore */ }
            }
        }

        override fun onError(error: Int) {
            when (state) {
                WakeState.LISTENING_FOR_WAKE -> {
                    // A short pause before retrying gives the recognizer time to actually reset —
                    // restarting instantly is what causes rapid on/off flicker loops.
                    transitionToWakeListening(delayMs = if (error == SpeechRecognizer.ERROR_NO_MATCH) 300 else 1200)
                }
                WakeState.LISTENING_FOR_COMMAND -> onCommandHeard("")
                else -> { /* ignore stray errors from a session we already moved past */ }
            }
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onPartialResults(partialResults: Bundle?) {}
    }

    private fun firstResult(results: Bundle?): String {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        return matches?.firstOrNull()?.lowercase()?.trim() ?: ""
    }

    private fun containsWakeWord(heard: String): Boolean {
        return heard.contains("hey sely") || heard.contains("hey sally") ||
            heard.contains("hey selly") || heard.contains("hey selle")
    }

    // ---- Wake-word listening ----
    private fun transitionToWakeListening(delayMs: Long = 0) {
        if (!enabled) {
            state = WakeState.IDLE
            return
        }
        state = WakeState.LISTENING_FOR_WAKE
        mainHandler.postDelayed({
            // Re-check: the toggle or state may have moved on during the delay.
            if (enabled && state == WakeState.LISTENING_FOR_WAKE) startWakeSession()
        }, delayMs)
    }

    private fun startWakeSession() {
        ensureRecognizer()
        val recognizer = speechRecognizer ?: return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2500)
        }
        try {
            recognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "startListening (wake) failed, retrying shortly", e)
            transitionToWakeListening(delayMs = 1500)
        }
    }

    // ---- "Hey Sely" heard: stop the wake recognizer, show the floating icon, then listen for
    // ONE command. The wake recognizer's session already ended (we're inside its onResults), so
    // there is nothing else to stop here beyond making sure we don't accidentally restart it. ----
    private fun beginCommandFlow() {
        state = WakeState.PROCESSING_COMMAND // blocks any relisten attempts while we set up

        val overlayGranted = Settings.canDrawOverlays(this)
        var greeting = "Hello boss, what do you need?"
        if (overlayGranted) {
            showFloatingIcon()
        } else {
            // Never silently skip the overlay — tell the user clearly, once per service run, both
            // in the notification and out loud, then keep going without the floating icon.
            updateNotification("Overlay permission missing — enable \"display over other apps\" for Sely in Settings")
            if (!overlayWarningGiven) {
                overlayWarningGiven = true
                greeting = "Heads up, I don't have permission to show my floating icon. " +
                    "Enable display over other apps for Sely in Settings when you get a chance. " +
                    greeting
            }
        }

        speak(greeting) {
            startCommandListeningSession()
        }
    }

    private fun startCommandListeningSession() {
        ensureRecognizer()
        val recognizer = speechRecognizer
        if (recognizer == null) {
            onCommandHeard("")
            return
        }
        state = WakeState.LISTENING_FOR_COMMAND
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        }
        try {
            recognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "startListening (command) failed", e)
            onCommandHeard("")
        }
    }

    private fun onCommandHeard(command: String) {
        removeFloatingIcon()
        state = WakeState.PROCESSING_COMMAND

        if (command.isEmpty()) {
            speak("Sorry, I didn't catch that.") { finishCommandCycle() }
            return
        }

        updateNotification("Running: \"$command\"")
        // Runs the command directly — no need to open MainActivity for this. The processor
        // always calls speak() exactly once when it's done, which is what resumes wake listening.
        commandProcessor.process(command)

        // Safety net: if nothing calls speak() within a generous window (unexpected exception
        // swallowed somewhere outside process()'s own try/catch, a hung network call beyond
        // Gemini's own timeout, etc.), don't leave Sely stuck forever — resume wake listening.
        mainHandler.postDelayed({
            if (state == WakeState.PROCESSING_COMMAND) {
                Log.e(TAG, "Command \"$command\" never completed via speak(); recovering.")
                finishCommandCycle()
            }
        }, SAFETY_TIMEOUT_MS)
    }

    // ---- SelyCommandProcessor.Callbacks ----
    // Command handlers almost always call speak(text) with no onDone — that's our signal this is
    // the terminal response for whatever we're doing. If we were mid-command (PROCESSING_COMMAND)
    // when that terminal speak() was made, its completion is exactly the point where wake-word
    // listening should resume. Callers that need to do something else first (start listening for
    // the command, resume a paused call flow, etc.) pass their own onDone and that takes priority.
    override fun speak(text: String, onDone: (() -> Unit)?) {
        mainHandler.post {
            val wasProcessingCommand = state == WakeState.PROCESSING_COMMAND
            state = WakeState.SPEAKING
            val completion: () -> Unit = {
                if (onDone != null) onDone.invoke() else if (wasProcessingCommand) finishCommandCycle()
            }
            if (!ttsReady) {
                completion()
                return@post
            }
            textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { mainHandler.post { completion() } }
                override fun onError(utteranceId: String?) { mainHandler.post { completion() } }
            })
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sely_wake_utterance")
        }
    }

    override fun updateStatus(text: String) {
        updateNotification(text)
    }

    // Kotlin doesn't let an interface override redeclare its default parameter value, so this
    // plain overload covers call sites here that don't care about the onDone callback.
    private fun speak(text: String) = speak(text, null)

    // Called once the terminal speak() for a command finishes — the only place wake-word
    // listening is allowed to resume after a command cycle.
    private fun finishCommandCycle() {
        if (awaitingCallResponse) return // call flow manages its own resume
        transitionToWakeListening(delayMs = 300)
    }

    // ---- Incoming call: announce who it is, then listen briefly for "pick up" ----
    private fun handleIncomingCall(callerLabel: String) {
        wasEnabledBeforeCall = enabled
        // If always-listen wasn't already on, this service instance was started fresh just for
        // this one call — stop it again once we're done instead of leaving it running forever.
        pendingSelfStop = !enabled
        awaitingCallResponse = true
        state = WakeState.HANDLING_CALL
        ensureRecognizer()
        // Stop whatever recognition session might currently be active (e.g. wake-word listening)
        // before we take over the mic for the call announcement — never run two sessions at once.
        try { speechRecognizer?.cancel() } catch (e: Exception) { /* nothing to cancel */ }

        speak("Incoming call from $callerLabel. Say pick up to answer.") {
            val recognizer = speechRecognizer
            if (recognizer == null) {
                finishCallHandling()
                return@speak
            }
            val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            }
            // Temporarily swap the listener for this one call-response session, then restore it.
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val heard = firstResult(results)
                    if (heard.contains("pick up") || heard.contains("answer")) acceptCall()
                    recognizer.setRecognitionListener(recognitionListener)
                    finishCallHandling()
                }
                override fun onError(error: Int) {
                    recognizer.setRecognitionListener(recognitionListener)
                    finishCallHandling()
                }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onPartialResults(partialResults: Bundle?) {}
            })
            try {
                recognizer.startListening(recognizerIntent)
            } catch (e: Exception) {
                recognizer.setRecognitionListener(recognitionListener)
                finishCallHandling()
                return@speak
            }
            // Safety timeout in case the call is picked up manually or nothing is heard.
            mainHandler.postDelayed({
                if (awaitingCallResponse) {
                    recognizer.setRecognitionListener(recognitionListener)
                    finishCallHandling()
                }
            }, 8000)
        }
    }

    private fun acceptCall() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ANSWER_PHONE_CALLS)
            != PackageManager.PERMISSION_GRANTED) {
            speak("I need call-answering permission first.")
            return
        }
        try {
            val telecomManager = getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager
            telecomManager.acceptRingingCall()

            val prefs = getSharedPreferences("sely_prefs", Context.MODE_PRIVATE)
            val busyMode = prefs.getBoolean("busy_mode", false)
            if (busyMode) {
                val message = prefs.getString("busy_call_message", DEFAULT_BUSY_CALL_MESSAGE) ?: DEFAULT_BUSY_CALL_MESSAGE
                mainHandler.postDelayed({ speakIntoCall(message) }, 1200)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Couldn't answer the call", e)
        }
    }

    // Best-effort: routes speech to the voice-call audio stream so the caller can hear it.
    // This is NOT guaranteed to work on every device/carrier — Android restricts third-party
    // apps from injecting audio into an active call on many phones for privacy reasons.
    private fun speakIntoCall(message: String) {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            audioManager.mode = android.media.AudioManager.MODE_IN_COMMUNICATION

            val params = Bundle()
            params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, android.media.AudioManager.STREAM_VOICE_CALL)

            val attributes = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            textToSpeech?.setAudioAttributes(attributes)

            textToSpeech?.speak(message, TextToSpeech.QUEUE_FLUSH, params, "sely_call_message")
        } catch (e: Exception) {
            // If this fails, the call is still answered — it just stays silent from Sely's side.
            Log.e(TAG, "speakIntoCall failed", e)
        }
    }

    private fun finishCallHandling() {
        if (!awaitingCallResponse) return
        awaitingCallResponse = false
        if (wasEnabledBeforeCall) {
            enabled = true
            transitionToWakeListening(delayMs = 300)
        } else if (pendingSelfStop) {
            stopSelf()
        } else {
            state = WakeState.IDLE
        }
    }

    companion object {
        const val DEFAULT_BUSY_CALL_MESSAGE = "This is Kingsley's personal assistant speaking with you. The person you are trying to reach is very busy. Please call back later."
        private const val TAG = "SelyWakeService"
        private const val NOTIFICATION_ID = 42
        private const val CHANNEL_ID = "sely_wake_service"
        // Comfortably longer than SelyCommandProcessor's Gemini read timeout (60s) so a normal
        // slow answer never races with this fallback.
        private const val SAFETY_TIMEOUT_MS = 75000L
    }

    private fun buildNotification(text: String): android.app.Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Sely Wake Word", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Sely is listening")
            .setContentText(text)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, buildNotification(text))
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update notification", e)
        }
    }

    // ---- Floating icon: requires SYSTEM_ALERT_WINDOW + Settings.canDrawOverlays(); uses
    // TYPE_APPLICATION_OVERLAY so it draws above other normal apps. Failures are logged and
    // surfaced via the notification instead of being silently swallowed. ----
    private fun showFloatingIcon() {
        if (floatingView != null) return
        if (!Settings.canDrawOverlays(this)) {
            updateNotification("Can't show floating icon — overlay permission not granted")
            return
        }
        try {
            val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val icon = ImageView(this)
            icon.setImageResource(R.drawable.sely_avatar)
            icon.background = ContextCompat.getDrawable(this, R.drawable.avatar_ring)
            val sizePx = (72 * resources.displayMetrics.density).toInt()
            val padding = (4 * resources.displayMetrics.density).toInt()
            icon.setPadding(padding, padding, padding, padding)
            icon.clipToOutline = true

            val params = WindowManager.LayoutParams(
                sizePx, sizePx,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.TOP or Gravity.END
            params.x = 24
            params.y = 200

            windowManager.addView(icon, params)
            floatingView = icon

            icon.alpha = 0f
            icon.scaleX = 0.5f
            icon.scaleY = 0.5f
            icon.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(250).start()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to show floating icon", e)
            updateNotification("Floating icon failed to show: ${e.javaClass.simpleName}")
        }
    }

    private fun removeFloatingIcon() {
        val view = floatingView ?: return
        try {
            val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            windowManager.removeView(view)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to remove floating icon (it may already be gone)", e)
        }
        floatingView = null
    }

    override fun onDestroy() {
        enabled = false
        state = WakeState.IDLE
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.setRecognitionListener(null)
        speechRecognizer?.destroy()
        speechRecognizer = null
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        removeFloatingIcon()
        super.onDestroy()
    }
}
